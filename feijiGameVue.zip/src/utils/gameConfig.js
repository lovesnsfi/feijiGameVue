/**
 * 游戏配置对象
 */
export default {
    width: 480, //游戏宽度
    height: 850, //游戏高度
    score: 0, //游戏得分
    nickName: '' //昵称
}