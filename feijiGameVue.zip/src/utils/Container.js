/**
 * 玩家飞机的子弹容器
 */
export const heroBulletArr = [];


/**
 * 游戏对象的图片
 */
export const imgObj = {};

/**
 * 玩家飞机的集合
 */
export const enemyArr = [];


/**
 * 敌机爆炸动画的集合
 */
export const boomArr = [];

/**
 * 双排子弹的倒具集合
 */

export const twoBulletArr = [];


/**
 * 全屏炸弹的道具集合
 */
export const fullBoomArr=[];